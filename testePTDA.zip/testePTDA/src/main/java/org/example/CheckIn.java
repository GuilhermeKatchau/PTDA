package org.example;

public class CheckIn {

    private int hCheckIn;
    private boolean checkIn;

    public int gethCheckIn() {
        return hCheckIn;
    }

    public boolean isCheckIn() {
        return checkIn;
    }

    public void sethCheckIn(int hCheckIn) {
        this.hCheckIn = hCheckIn;
    }

    public void setCheckIn(boolean checkIn) {
        this.checkIn = checkIn;
    }
}

